package com.web.god.xposed;

import android.text.TextUtils;
import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;

import java.io.InputStream;

/**
 * Created by anson on 2020-03-15.
 */
public class XmlParser {

    /**
     * xml pull 解析
     * @return
     */
    public static String getNativeUrl(InputStream inputStream) {
        XmlPullParser xmlPullParser = Xml.newPullParser();
        try {
            xmlPullParser.setInput(inputStream,"UTF-8");
            int eventType = xmlPullParser.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_TAG:
                        if (TextUtils.equals("nativeurl", xmlPullParser.getName())) {
                            return xmlPullParser.nextText().trim();
                        }
                        break;
                }
                eventType = xmlPullParser.next();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
