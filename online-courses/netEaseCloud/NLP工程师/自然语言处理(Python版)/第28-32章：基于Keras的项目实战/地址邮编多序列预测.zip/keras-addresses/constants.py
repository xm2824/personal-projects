ADDRESS_FILE = 'addresses4.txt'

INVERT = False

ADD_NOISE_TO_DATA = True

# 不同变化的概率值
NOISE_PROBS = [0.4, 0.2, 0.2, 0.2]
