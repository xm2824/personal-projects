import codecs,sys


f=codecs.open('zh.jian.wiki.seg-1.3gg.txt','r',encoding="utf8")
line=f.readline()
print(line)