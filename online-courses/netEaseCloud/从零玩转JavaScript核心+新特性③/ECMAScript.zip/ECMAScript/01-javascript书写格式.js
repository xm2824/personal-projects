// alert('lnj888');

/*
var oDiv = document.querySelector("div");
var text = oDiv.innerText;
alert(text);
*/

// window.onload = function () {
    var oDiv = document.querySelector("div");
    var text = oDiv.innerText;
    alert(text);
// }